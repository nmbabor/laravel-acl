<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStoragesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('storages', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('company_id',false,11);
            $table->integer('branch_id',false,11);
            $table->string('storage_name',200)->nullable();
            $table->text('address')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->integer('created_by',false,11);
            $table->integer('updated_by',false,11)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('storages');
    }
}
